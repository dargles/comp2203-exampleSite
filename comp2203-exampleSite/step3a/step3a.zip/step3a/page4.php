<?php 
 include("library/htmlCode.php");
 streamTop("Page 4"); 
?>
 <!-- Our main page content follows -->
 <h3>Page Four</h3>
 <p>Lastly, we get onto page four of our little website.</p>
<?php
 include("library/templateBottom.html");
?>