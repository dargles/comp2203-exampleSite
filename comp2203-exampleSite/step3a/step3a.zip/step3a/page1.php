<?php 
 include("library/htmlCode.php");
 streamTop("Page 1"); 
?>
 <!-- Our main page content follows -->
 <h3>Welcome!</h3>
 <p>Welcome to my Site!</p>
<?php
 include("library/templateBottom.html");
?>