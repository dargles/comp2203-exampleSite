<?php 
 include("library/htmlCode.php");
 streamTop("Page 2"); 
?>
 <!-- Our main page content follows -->
 <h3>Page 2</h3>
 <p>This is page 2.</p>
<?php
 include("library/templateBottom.html");
?>