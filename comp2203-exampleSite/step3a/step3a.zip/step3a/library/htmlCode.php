<?php 
 function streamTop($title) 
 {
   include("library/templateTop1.html");
   echo($title);
   include("library/templateTop2.html");
 }
?>