<?php 
 include("library/htmlCode.php");
 streamTop("Page 3"); 
?>
 <!-- Our main page content follows -->
 <h3>Page 3</h3>
 <p>Now we're onto page 3.</p>
<?php
 include("library/templateBottom.html");
?>