Notes for step3a
================

This example is a dead end!  So the numbering goes to "3a" because we will be 
going nowhere else with this example.  It is designed solely to introduce the 
concept of PHP functions and so we can see how to pass parameters to our 
functions.

It is designed to solve a little problem however - the fact that we're using 
partials, yet we need to be able to alter a bit of text in the middle of our 
partial.  The solution we give here works - but we will backtrack and provide 
a much better solution in step 4.

As before, you can inspect the code by downloading it and looking at it in a 
text editor.  However, we are now using PHP, and PHP is security-conscious.  
That means that the server will interpret the PHP *before* downloading it onto 
your computer.  So to get around that, I'm now providing a zip file which 
contains all the code for this example.  Download the zip file, then unzip it 
and explore.  Have fun!

D.A.Argles
13.10.2014 @ 15:31h