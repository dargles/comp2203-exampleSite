Notes for step3
===============

This example switches from using single html pages to partials - you can see the files in the 
library subdirectory, called "templateTop.php" and "templateBottom.php".

As before, you can inspect the individual pages' code by downloading it and looking at it in a 
text editor.

D.A.Argles
03.09.2014 @ 17:37h